var express = require('express')
var app = express()
var bodyParser = require('body-parser');

// support parsing of application/json type post data
app.use(bodyParser.json());

//support parsing of application/x-www-form-urlencoded post data
app.use(bodyParser.urlencoded({ extended: true }));


// GET method route
app.get('/api', function (req, res) {
    res.send({message: 'THis is a sample GET API'})
  })
  
  // POST method route
  app.post('/api', function (req, res) {
    res.send({message: 'THis is a sample POST API'})
  })

  app.listen(7071, ()=>{console.log('Server started at port 7071')});
